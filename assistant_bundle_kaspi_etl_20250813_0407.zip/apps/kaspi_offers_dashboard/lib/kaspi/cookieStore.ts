import fs from 'node:fs'
import path from 'node:path'

const FILE = path.join(process.cwd(), 'apps', 'kaspi_offers_dashboard', 'server', 'db', 'merchant.cookie.json')

export function readCookieFromStore(): string | null {
  try {
    const raw = fs.readFileSync(FILE, 'utf-8')
    const js = JSON.parse(raw)
    return typeof js?.cookie === 'string' && js.cookie.length > 0 ? js.cookie : null
  } catch {
    return null
  }
}

export function writeCookieToStore(cookie: string): void {
  const dir = path.dirname(FILE)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
  fs.writeFileSync(FILE, JSON.stringify({ cookie, updatedAt: new Date().toISOString() }, null, 2))
}


