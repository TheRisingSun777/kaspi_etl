import fs from 'node:fs'
import path from 'node:path'

export function readCookieForMerchant(merchantId?: string): string | null {
  if (!merchantId) return null
  const cwd = process.cwd()
  const candidates = [
    // Primary (app runtime cwd is usually apps/kaspi_offers_dashboard)
    path.join(cwd, 'server', 'merchant', `${merchantId}.cookie.json`),
    path.join(cwd, 'server', 'cookies', `${merchantId}.json`),
    path.join(cwd, 'server', 'db', 'cookies', `${merchantId}.json`),
    // Fallback if cwd is repository root
    path.join(cwd, 'apps', 'kaspi_offers_dashboard', 'server', 'merchant', `${merchantId}.cookie.json`),
    path.join(cwd, 'apps', 'kaspi_offers_dashboard', 'server', 'cookies', `${merchantId}.json`),
    path.join(cwd, 'apps', 'kaspi_offers_dashboard', 'server', 'db', 'cookies', `${merchantId}.json`),
  ]
  for (const file of candidates) {
    try {
      const raw = fs.readFileSync(file, 'utf-8')
      const js = JSON.parse(raw)
      // Prefer direct cookie string
      const str = js.cookie || js.cookies || js.Cookie || ''
      if (typeof str === 'string' && str.trim()) return str.trim()
      // Or build from cookies array
      if (Array.isArray(js.cookies)) {
        const cookieHeader = js.cookies.map((c:any)=> `${c.name}=${c.value}`).join('; ')
        if (cookieHeader) return cookieHeader
      }
    } catch {}
  }
  return null
}


