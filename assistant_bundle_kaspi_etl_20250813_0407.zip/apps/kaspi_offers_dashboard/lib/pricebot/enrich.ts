import type { Row } from './types'

const inflight = new Map<string, Promise<Row>>()

export function enrichRow(row: Row, { cityId }: { cityId: string }): Promise<Row> {
  const key = `${row.masterId}:${cityId}`
  const ex = inflight.get(key)
  if (ex) return ex
  const p = (async()=>{
    try {
      const res = await fetch('/api/analyze', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ masterProductId: row.masterId, cityId }) })
      const js = await res.json()
      const v = Array.isArray(js?.variants) ? js.variants.find((x:any)=>String(x.productId)===String(row.variantId) || true) : null
      const sellers = Array.isArray(v?.sellers) ? v.sellers.map((s:any)=>({ name: s.name, price: Number(s.price||0), delivery: s.deliveryDate, isPriceBot: !!s.isPriceBot })) : []
      const sellersCount = Number(v?.sellersCount || sellers.length || 0)
      return { ...row, sellers, sellersCount, min: v?.stats?.min ?? row.min, max: v?.stats?.max ?? row.max, spread: v?.stats?.spread ?? row.spread, deliveryBest: js?.fastestDelivery, ratingAvg: v?.rating?.avg ?? row.ratingAvg, ratingCount: v?.rating?.count ?? row.ratingCount }
    } catch {
      return row
    } finally {
      inflight.delete(key)
    }
  })()
  inflight.set(key, p)
  return p
}


