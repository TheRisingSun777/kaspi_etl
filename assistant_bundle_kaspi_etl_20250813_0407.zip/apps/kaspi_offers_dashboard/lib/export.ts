// lib/export.ts
import Papa from 'papaparse'
import * as XLSX from 'xlsx'
import type { AnalyzeResult } from './types'

function flattenRows(data: AnalyzeResult) {
  const meta = data.variantMap || {}
  const rows: Record<string, unknown>[] = []
  for (const v of data.variants) {
    const sellers = v.sellers.length ? v.sellers : [{ name: 'Out of stock', price: 0, deliveryDate: '' }]
    for (const s of sellers) {
      rows.push({
        masterProductId: data.masterProductId,
        productName: (meta[v.productId]?.name || v.label || data.productName || '').trim(),
        variantProductId: v.productId,
        variantSize: v.variantSize || v.label || '',
        variantColor: v.variantColor || meta[v.productId]?.color || '',
        ratingAvg: v.rating?.avg ?? '',
        ratingCount: v.rating?.count ?? '',
        min: v.stats?.min ?? '',
        median: v.stats?.median ?? '',
        max: v.stats?.max ?? '',
        spread: v.stats?.spread ?? '',
        stddev: v.stats?.stddev ?? '',
        seller: s.name,
        price: s.price,
        deliveryDate: s.deliveryDate || '',
      })
    }
  }
  return rows
}

export function exportCSV(data: AnalyzeResult): string {
  return Papa.unparse(flattenRows(data))
}

export function exportXLSX(data: AnalyzeResult): ArrayBuffer {
  const ws = XLSX.utils.json_to_sheet(flattenRows(data))
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, 'Offers')
  return XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
}

