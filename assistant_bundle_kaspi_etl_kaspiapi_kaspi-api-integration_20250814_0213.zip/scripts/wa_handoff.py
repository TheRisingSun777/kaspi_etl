#!/usr/bin/env python3
"""
macOS handoff helper:
- Opens Finder at outbox/<date>
- Copies shipment_<date>.zip (or bundle_<date>.zip / newest *.zip) absolute path to clipboard
- Optionally opens WhatsApp Desktop (with --open-wa)

Usage:
  ./venv/bin/python scripts/wa_handoff.py --date 2025-08-14 [--open-wa]
"""

from __future__ import annotations

import argparse
import platform
import subprocess
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]


def open_in_finder(path: Path) -> None:
    try:
        subprocess.run(["open", str(path)], check=False)
    except Exception:
        pass


def copy_to_clipboard(text: str) -> None:
    try:
        subprocess.run(["pbcopy"], input=text.encode("utf-8"), check=False)
    except Exception:
        pass


def open_whatsapp() -> None:
    try:
        subprocess.run(["open", "-a", "WhatsApp"], check=False)
    except Exception:
        pass


def pick_zip(out_dir: Path, date_str: str) -> Path | None:
    shipment = out_dir / f"shipment_{date_str}.zip"
    if shipment.exists():
        return shipment.resolve()
    bundle = out_dir / f"bundle_{date_str}.zip"
    if bundle.exists():
        return bundle.resolve()
    zips = sorted(out_dir.glob("*.zip"))
    if zips:
        return zips[-1].resolve()
    return None


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="macOS WA handoff helper")
    parser.add_argument("--date", required=True, help="Target date folder YYYY-MM-DD")
    parser.add_argument("--open-wa", action="store_true", help="Also open WhatsApp Desktop")
    args = parser.parse_args(argv)

    if platform.system() != "Darwin":
        print("This helper is intended for macOS (Darwin)")
        return 0

    out_dir = REPO_ROOT / "outbox" / args.date
    open_in_finder(out_dir)

    chosen = pick_zip(out_dir, args.date)
    if chosen is not None:
        copy_to_clipboard(str(chosen))
        print("Copied to clipboard:", chosen)
    else:
        print("No ZIP found under:", out_dir)

    if args.open_wa:
        open_whatsapp()

    # Echo paths for terminal users
    print("Outbox folder:", out_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


