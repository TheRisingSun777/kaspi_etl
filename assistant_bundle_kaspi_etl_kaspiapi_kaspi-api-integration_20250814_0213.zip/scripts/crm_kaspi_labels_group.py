#!/usr/bin/env python3
"""
Group Kaspi PDF labels by (sku_key, my_size) using processed sales mapping, with fallbacks.

Usage:
  ./venv/bin/python scripts/crm_kaspi_labels_group.py --input waybill-327.zip \
      [--processed data_crm/processed_sales_latest.csv] [--out-date 2025-08-13]

- Accepts either a ZIP archive of label PDFs or a directory containing PDFs.
- Reads processed sales CSV to map orderid -> (sku_key, my_size).
- For each group, merges PDFs into data_crm/labels_grouped/YYYY-MM-DD/{sku_key}_{my_size}.pdf
- Writes a manifest CSV with one row per source PDF and the matching method used.
"""

import argparse
import csv
import logging
import re
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Dict, Iterable, List, Optional, Tuple

import pandas as pd
from pypdf import PdfReader, PdfWriter


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")
logger = logging.getLogger(__name__)

REPO_ROOT = Path(__file__).resolve().parents[1]
DATA_CRM = REPO_ROOT / "data_crm"
DEFAULT_PROCESSED = DATA_CRM / "processed_sales_latest.csv"


def _lower_columns_inplace(df: pd.DataFrame) -> None:
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]


def _safe_slug(text: str) -> str:
    text = (text or "").strip()
    # Replace spaces with underscore, drop unsafe characters
    text = re.sub(r"\s+", "_", text)
    text = re.sub(r"[^A-Za-z0-9_.-]", "", text)
    return text or "UNKNOWN"


def _extract_orderid_from_name(name: str) -> Optional[str]:
    """Extract order id from a label filename using 7+ digit sequence.

    Example: KASPI_SHOP-611444195.pdf -> 611444195
    """
    base = Path(name).stem
    matches = re.findall(r"(\d{7,})", base)
    if not matches:
        return None
    return matches[-1]


def _extract_orderid_from_pdf_text(pdf_path: Path) -> Optional[str]:
    try:
        reader = PdfReader(str(pdf_path))
        if len(reader.pages) == 0:
            return None
        text = reader.pages[0].extract_text() or ""
        m = re.search(r"(\d{7,})", text)
        return m.group(1) if m else None
    except Exception:
        return None


def _find_processed_csv(default_path: Path) -> Path:
    if default_path.exists():
        return default_path
    # Fallback to latest dated processed file
    candidates = sorted((DATA_CRM / "processed").glob("processed_sales_*.csv"))
    if candidates:
        return candidates[-1]
    raise FileNotFoundError(
        f"Processed sales CSV not found. Expected {default_path} or data_crm/processed/processed_sales_*.csv"
    )


def load_order_group_mapping(processed_csv: Path) -> Dict[str, Tuple[str, str]]:
    df = pd.read_csv(processed_csv)
    if df.empty:
        return {}
    _lower_columns_inplace(df)

    for col in ["orderid", "sku_key", "my_size"]:
        if col not in df.columns:
            df[col] = ""

    # Normalize types and whitespace
    df["orderid"] = df["orderid"].astype(str).str.replace(".0", "", regex=False).str.strip()
    df["sku_key"] = df["sku_key"].astype(str).str.strip()
    df["my_size"] = df["my_size"].astype(str).str.strip()

    mapping: Dict[str, Tuple[str, str]] = {}
    # Prefer first non-empty occurrence per orderid
    for _, row in df.iterrows():
        oid = row.get("orderid", "")
        if not oid or oid.lower() in {"nan", "none", "null"}:
            continue
        if oid in mapping:
            # Keep first mapping if existing has non-empty fields
            continue
        sku_key = row.get("sku_key", "") or ""
        my_size = row.get("my_size", "") or ""
        mapping[str(oid)] = (str(sku_key), str(my_size))
    return mapping


def load_api_orders_mapping() -> Dict[str, Tuple[str, str]]:
    """Best-effort mapping from orders_api_latest.csv when processed missing.

    Returns orderid -> (sku_key, my_size)
    """
    api_csv = DATA_CRM / "orders_api_latest.csv"
    if not api_csv.exists():
        return {}
    try:
        df = pd.read_csv(api_csv)
    except Exception:
        return {}
    _lower_columns_inplace(df)
    for col in ["orderid", "sku_key", "my_size", "product_master_code"]:
        if col not in df.columns:
            df[col] = ""
    df["orderid"] = df["orderid"].astype(str).str.replace(".0", "", regex=False).str.strip()
    df["sku_key"] = df["sku_key"].astype(str).str.strip()
    df["my_size"] = df["my_size"].astype(str).str.strip()
    # If sku_key empty but product_master_code present, use it
    df["sku_key"] = df.apply(
        lambda r: r["sku_key"] if str(r["sku_key"]).strip() else str(r.get("product_master_code", "")).strip(),
        axis=1,
    )
    mapping: Dict[str, Tuple[str, str]] = {}
    for _, r in df.iterrows():
        oid = r.get("orderid", "")
        if not oid or oid.lower() in {"nan", "none", "null"}:
            continue
        mapping[str(oid)] = (str(r.get("sku_key", "") or ""), str(r.get("my_size", "") or ""))
    return mapping


def _load_processed_df(processed_csv: Path) -> pd.DataFrame:
    df = pd.read_csv(processed_csv)
    if df.empty:
        return df
    _lower_columns_inplace(df)
    # Ensure columns exist
    for col in ["orderid", "sku_key", "my_size", "ksp_sku_id", "qty", "join_code"]:
        if col not in df.columns:
            df[col] = ""
    # Normalize
    df["orderid"] = df["orderid"].astype(str).str.replace(".0", "", regex=False).str.strip()
    df["sku_key"] = df["sku_key"].astype(str).str.strip()
    df["my_size"] = df["my_size"].astype(str).str.strip()
    df["ksp_sku_id"] = df["ksp_sku_id"].astype(str).str.strip()
    df["join_code"] = df["join_code"].astype(str).str.strip()
    # qty numeric helper
    with pd.option_context('mode.chained_assignment', None):
        df["_qty_num"] = pd.to_numeric(df.get("qty", 1), errors="coerce").fillna(1).astype(int)
    return df


def _extract_pdf_text(pdf_path: Path) -> str:
    try:
        reader = PdfReader(str(pdf_path))
        return "\n".join([(p.extract_text() or "") for p in reader.pages])
    except Exception:
        return ""


def _tokenize(text: str) -> List[str]:
    return re.findall(r"[A-Za-z0-9_\-]+", text or "")


def _choose_ksp_candidate(rows: List[Dict]) -> Optional[Dict]:
    if not rows:
        return None
    qty1 = [r for r in rows if int(r.get("_qty_num", 0)) == 1]
    if len(qty1) == 1:
        return qty1[0]
    uniq = {(str(r.get("sku_key", "")), str(r.get("my_size", ""))): r for r in rows}
    if len(uniq) == 1:
        return list(uniq.values())[0]
    return rows[0]


@dataclass
class GroupEntry:
    sku_key: str
    my_size: str
    pdf_paths: List[Path]


def merge_group_to_pdf(pdf_paths: Iterable[Path], output_pdf: Path) -> None:
    output_pdf.parent.mkdir(parents=True, exist_ok=True)
    writer = PdfWriter()
    for p in pdf_paths:
        reader = PdfReader(str(p))
        for page in reader.pages:
            writer.add_page(page)
    with output_pdf.open("wb") as f:
        writer.write(f)


def discover_label_pdfs_from_dir(input_dir: Path) -> Tuple[Path, List[Path]]:
    if not input_dir.is_dir():
        raise FileNotFoundError(f"Directory not found: {input_dir}")
    pdfs = sorted([p for p in input_dir.rglob("*.pdf") if p.is_file()])
    return input_dir, pdfs


def group_labels(
    input_path: Path,
    processed_csv: Path,
    out_date: Optional[str] = None,
) -> Tuple[Path, List[GroupEntry], Path]:
    processed_csv = _find_processed_csv(processed_csv)
    order_to_group = load_order_group_mapping(processed_csv)
    df_full = _load_processed_df(processed_csv)
    # Build lookup maps for fallbacks
    join_code_map: Dict[str, List[Dict]] = {}
    ksp_map: Dict[str, List[Dict]] = {}
    if not df_full.empty:
        # Index join_code → rows
        if "join_code" in df_full.columns:
            tmp = df_full[df_full["join_code"].astype(str).str.strip() != ""].copy()
            for _, r in tmp.iterrows():
                key = str(r.get("join_code", "")).strip().lower()
                join_code_map.setdefault(key, []).append(r.to_dict())
        # Index ksp_sku_id → rows
        if "ksp_sku_id" in df_full.columns:
            tmp = df_full[df_full["ksp_sku_id"].astype(str).str.strip() != ""].copy()
            for _, r in tmp.iterrows():
                key = str(r.get("ksp_sku_id", "")).strip().lower()
                ksp_map.setdefault(key, []).append(r.to_dict())
    # Enrich with API orders mapping for any missing orderids
    api_map = load_api_orders_mapping()
    for oid, tup in api_map.items():
        if oid not in order_to_group:
            order_to_group[oid] = tup
    if not order_to_group:
        logger.warning("Processed sales CSV has no mapping rows: %s", processed_csv)

    # Prepare source PDFs, handling ZIP extraction with a temp directory
    tmpdir_obj: Optional[TemporaryDirectory] = None
    if input_path.is_file() and input_path.suffix.lower() == ".zip":
        tmpdir_obj = TemporaryDirectory()
        holder_dir = Path(tmpdir_obj.name)
        shutil.unpack_archive(str(input_path), extract_dir=str(holder_dir))
        pdfs = sorted([p for p in holder_dir.rglob("*.pdf") if p.is_file()])
    elif input_path.is_dir():
        holder_dir, pdfs = discover_label_pdfs_from_dir(input_path)
    else:
        raise FileNotFoundError(f"Input path not found or unsupported: {input_path}")
    logger.info("Found %d PDF labels", len(pdfs))

    # Collect PDFs per group
    group_map: Dict[Tuple[str, str], List[Path]] = {}
    unmatched: List[Path] = []
    manifest_rows: List[Dict[str, str]] = []
    for pdf in pdfs:
        match_method = ""
        ksp_sku_id_val = ""
        oid = _extract_orderid_from_name(pdf.name) or _extract_orderid_from_pdf_text(pdf)
        if oid and oid in order_to_group:
            sku_key, my_size = order_to_group[oid]
            match_method = "orderid"
        else:
            # Fallbacks
            text_all = f"{pdf.name}\n" + _extract_pdf_text(pdf)
            tokens = set(t.lower() for t in _tokenize(text_all))
            # 1) join_code exact token
            chosen_row: Optional[Dict] = None
            candidates: List[Dict] = []
            hits = [t for t in tokens if t in join_code_map]
            if len(hits) == 1:
                candidates = join_code_map[hits[0]]
                chosen_row = _choose_ksp_candidate(candidates)
                match_method = "join_code"
            # 2) ksp_sku_id substring if still no match
            if chosen_row is None and ksp_map:
                text_lc = text_all.lower()
                ksp_hits = [k for k in ksp_map.keys() if k and k in text_lc]
                if len(ksp_hits) == 1:
                    candidates = ksp_map[ksp_hits[0]]
                    chosen_row = _choose_ksp_candidate(candidates)
                    match_method = "ksp_sku_id"
            if chosen_row is not None:
                oid = str(chosen_row.get("orderid", "")).strip() or oid or ""
                sku_key = str(chosen_row.get("sku_key", "")).strip()
                my_size = str(chosen_row.get("my_size", "")).strip()
                ksp_sku_id_val = str(chosen_row.get("ksp_sku_id", "")).strip()
            else:
                unmatched.append(pdf)
                continue
        key = (sku_key or "UNKNOWN", (my_size or "UNK"))
        key = (sku_key or "UNKNOWN", (my_size or "UNK"))
        group_map.setdefault(key, []).append(pdf)
        manifest_rows.append(
            {
                "pdf_file": str(pdf.relative_to(REPO_ROOT)) if pdf.is_relative_to(REPO_ROOT) else str(pdf),
                "orderid": str(oid or ""),
                "sku_key": sku_key,
                "my_size": my_size if my_size else "UNK",
                "ksp_sku_id": ksp_sku_id_val,
                "match_method": match_method or ("orderid" if oid in order_to_group else ""),
            }
        )

    # Output directory
    date_tag = out_date or pd.Timestamp.utcnow().strftime("%Y-%m-%d")
    out_dir = DATA_CRM / "labels_grouped" / date_tag
    out_dir.mkdir(parents=True, exist_ok=True)

    # Merge and record manifest
    groups: List[GroupEntry] = []
    for (sku_key, my_size_key), paths in sorted(group_map.items(), key=lambda kv: (kv[0][0], kv[0][1])):
        safe_name = f"{_safe_slug(sku_key)}_{_safe_slug(my_size_key)}".strip("_")
        output_pdf = out_dir / f"{safe_name}.pdf"
        merge_group_to_pdf(paths, output_pdf)
        groups.append(GroupEntry(sku_key=sku_key, my_size=my_size_key, pdf_paths=paths))
        for p in paths:
            oid = _extract_orderid_from_name(p.name) or _extract_orderid_from_pdf_text(p) or ""
            # group_file not required in new manifest spec; keep grouping only

    # Write manifest
    manifest_csv = out_dir / "manifest.csv"
    with manifest_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["pdf_file", "orderid", "sku_key", "my_size", "ksp_sku_id", "match_method"],
        )
        writer.writeheader()
        for row in manifest_rows:
            writer.writerow(row)

    # Also write unmatched list for operator visibility
    if unmatched:
        unmatched_txt = out_dir / "unmatched_files.txt"
        unmatched_txt.write_text("\n".join(str(p) for p in unmatched), encoding="utf-8")
        logger.warning("Unmatched PDFs (no orderid or no mapping): %d (see %s)", len(unmatched), unmatched_txt)

    # Explicitly cleanup temp extraction directory if used
    if tmpdir_obj is not None:
        try:
            tmpdir_obj.cleanup()
        except Exception:
            pass

    return out_dir, groups, manifest_csv


def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Group Kaspi PDF labels by SKU and size")
    p.add_argument("--input", "-i", required=True, help="ZIP file or directory with raw label PDFs")
    p.add_argument(
        "--processed",
        "-p",
        default=str(DEFAULT_PROCESSED),
        help="Processed sales CSV path (default: data_crm/processed_sales_latest.csv)",
    )
    p.add_argument(
        "--out-date",
        default=None,
        help="Override output date folder, e.g., 2025-08-13 (default: today UTC)",
    )
    return p.parse_args(argv)


def main(argv: Optional[List[str]] = None) -> int:
    args = parse_args(argv)
    in_path = Path(args.input)
    processed = Path(args.processed)

    try:
        out_dir, groups, manifest_csv = group_labels(in_path, processed, args.out_date)
    except Exception as e:
        logger.exception("Failed to group labels: %s", e)
        return 1

    logger.info("Grouped %d buckets → %s", len(groups), out_dir)
    print(str(manifest_csv))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


