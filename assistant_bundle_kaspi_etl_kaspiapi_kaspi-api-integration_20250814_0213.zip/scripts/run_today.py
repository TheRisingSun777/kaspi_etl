#!/usr/bin/env python3
"""
Run end-to-end daily chain:
1) api_orders_to_csv.py (best-effort: from INPUT JSON if provided; else try live; else skip)
2) join_api_orders_to_sales.py
3) link_orders_and_sizes.py
4) crm_kaspi_labels_group.py (requires --input ZIP/dir with PDFs)
5) crm_build_picklist.py
6) outbox_pack.py

Prints paths to key outputs at the end.
"""

from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
PY = str((REPO_ROOT / "venv" / "bin" / "python").resolve())


def run(cmd: list[str]) -> int:
    print("$", " ".join(cmd))
    return subprocess.call(cmd, cwd=str(REPO_ROOT))


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Run daily Kaspi CRM chain")
    p.add_argument("--input", required=True, help="Waybill ZIP or directory with label PDFs")
    p.add_argument("--date", required=False, default=None, help="Output date folder YYYY-MM-DD (default: today)")
    p.add_argument("--input-json", required=False, default=None, help="Optional orders JSON cache path for API step")
    args = p.parse_args(argv)

    labels_input = Path(args.input)
    if not labels_input.exists():
        print(f"INPUT not found: {labels_input}", file=sys.stderr)
        return 2

    out_date = args.date

    # 1) Orders → CSV (best-effort)
    orders_json = args.input_json or os.environ.get("INPUT_JSON")
    api_cmd = [PY, "scripts/api_orders_to_csv.py"]
    if orders_json:
        api_cmd += ["--input", str(orders_json)]
    _ = run(api_cmd)

    # 2) Join orders to sales
    if run([PY, "scripts/join_api_orders_to_sales.py"]) != 0:
        print("join_api_orders_to_sales failed", file=sys.stderr)
        return 3

    # 3) Link orders and sizes
    if run([PY, "scripts/link_orders_and_sizes.py"]) != 0:
        print("link_orders_and_sizes failed", file=sys.stderr)
        return 4

    # 4) Group labels
    group_cmd = [PY, "scripts/crm_kaspi_labels_group.py", "--input", str(labels_input)]
    if out_date:
        group_cmd += ["--out-date", out_date]
    if run(group_cmd) != 0:
        print("label grouping failed", file=sys.stderr)
        return 5

    # 5) Build picklist
    if run([PY, "scripts/crm_build_picklist.py"]) != 0:
        print("picklist build failed", file=sys.stderr)
        return 6

    # 6) Outbox pack
    pack_cmd = [PY, "scripts/outbox_pack.py"]
    if out_date:
        pack_cmd += ["--out-date", out_date]
    if run(pack_cmd) != 0:
        print("outbox pack failed", file=sys.stderr)
        return 7

    # Echo outputs
    latest_manifest = None
    labels_dir = REPO_ROOT / "data_crm" / "labels_grouped"
    if labels_dir.exists():
        cands = sorted(labels_dir.rglob("manifest.csv"))
        latest_manifest = cands[-1] if cands else None
    picklist_csv = REPO_ROOT / "data_crm" / "picklist" / (out_date or "") / "picklist.csv"
    picklist_pdf = REPO_ROOT / "data_crm" / "picklist" / (out_date or "") / "picklist.pdf"
    outbox_zip = REPO_ROOT / "outbox" / (out_date or "") / (f"bundle_{out_date}.zip" if out_date else "")

    print("Outputs:")
    if latest_manifest:
        print("- labels manifest:", latest_manifest)
    if picklist_csv.exists():
        print("- picklist csv:", picklist_csv)
    if picklist_pdf.exists():
        print("- picklist pdf:", picklist_pdf)
    if outbox_zip.exists():
        print("- outbox bundle:", outbox_zip)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())


