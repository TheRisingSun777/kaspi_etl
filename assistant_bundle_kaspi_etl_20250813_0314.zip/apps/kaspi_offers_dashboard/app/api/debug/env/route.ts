import { NextResponse } from 'next/server';

export function GET() {
  // Booleans only; no secret values are returned
  return NextResponse.json({
    hasKey:  !!process.env.KASPI_MERCHANT_API_KEY,
    hasId:   !!process.env.KASPI_MERCHANT_ID,
    hasBase: !!process.env.KASPI_MERCHANT_API_BASE,
  });
}