2025‑08‑13: I.1 Picklist CSV/PDF generated (crm-system)
