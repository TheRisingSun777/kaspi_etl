/* eslint-disable @typescript-eslint/no-explicit-any */
const BASE = process.env.KASPI_MERCHANT_API_BASE || 'https://mc.shop.kaspi.kz'
const AUTH_MODE = process.env.KASPI_MERCHANT_AUTH_MODE || 'cookie'
const FALLBACK_COOKIE_FROM_STORE = true
import { readCookieFromStore } from '@/lib/kaspi/cookieStore'

function authHeaders() {
  if (AUTH_MODE === 'cookie') {
    const cookie = process.env.KASPI_MERCHANT_COOKIE || process.env.KASPI_MERCHANT_COOKIES || (FALLBACK_COOKIE_FROM_STORE ? (readCookieFromStore() || '') : '')
    if (!cookie) throw new Error('KASPI_MERCHANT_COOKIE is missing')
    return { Cookie: cookie }
  }
  const key = process.env.KASPI_MERCHANT_API_KEY
  if (!key) throw new Error('KASPI_MERCHANT_API_KEY is missing')
  // Many MC endpoints expect only X-Auth-Token, not a Bearer token
  return { 'X-Auth-Token': key }
}

export function getMerchantId(): string {
  const m = process.env.KASPI_MERCHANT_ID
  if (!m) throw new Error('KASPI_MERCHANT_ID is missing')
  return m
}

export async function mcFetch(path: string, init: RequestInit = {}) {
  const url = `${BASE}${path}`
  const headers = {
    accept: 'application/json, text/plain, */*',
    'content-type': 'application/json',
    origin: 'https://kaspi.kz',
    referer: 'https://kaspi.kz/',
    'x-auth-version': '3',
    'accept-language': 'ru-RU,ru;q=0.9',
    'user-agent':
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome Safari',
    ...authHeaders(),
    ...(init.headers as any || {}),
  } as Record<string, string>

  const res = await fetch(url, { ...init, headers, cache: 'no-store', redirect: 'follow' })
  if (!res.ok) {
    const text = await res.text().catch(() => '')
    throw new Error(`Kaspi MC ${res.status}: ${text.slice(0, 500)}`)
  }
  return res
}


