// 'use client'
import PricebotPageClient from '@/components/pricebot/PricebotPageClient'

export const dynamic = 'force-dynamic'

export default function PricebotPage() {
  return <PricebotPageClient />
}


