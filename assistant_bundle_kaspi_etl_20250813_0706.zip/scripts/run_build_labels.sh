#!/usr/bin/env bash
set -euo pipefail

echo "labels build skipped (stub)"


