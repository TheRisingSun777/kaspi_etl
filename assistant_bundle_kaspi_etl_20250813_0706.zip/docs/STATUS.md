## Status — 2025-08-13T06:25:07+00:00

### Workflow counts

### Waiting thresholds
- WAITING_SIZE_INFO >3h: 0
- WAITING_CONFIRM >1h: 0

### Low-stock top-10
(none)

