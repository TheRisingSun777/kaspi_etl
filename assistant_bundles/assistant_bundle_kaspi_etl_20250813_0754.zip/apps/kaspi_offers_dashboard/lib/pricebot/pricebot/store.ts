import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { Row } from './types'

type PricebotState = {
  rows: Row[]
  loading: boolean
  error?: string
  cityId: string
  storeId?: string
  setStoreId: (_id?: string)=>void
  setCityId: (_id: string)=>void
  setRows: (_rows: Row[])=>void
  patchRow: (_key: string, _patch: Partial<Row>)=>void
  loadOffers: (_storeId?: string)=>Promise<void>
}

export const usePricebotStore = create<PricebotState>()(persist((set, get)=>({
  rows: [],
  loading: false,
  error: undefined,
  cityId: String(process.env.NEXT_PUBLIC_DEFAULT_CITY_ID || '710000000'),
  storeId: undefined,
  setStoreId: (newStoreId?: string)=> set({ storeId: newStoreId }),
  setCityId: (newCityId: string)=> set({ cityId: newCityId }),
  setRows: (rowsList: Row[])=> set({ rows: rowsList }),
  patchRow: (rowKey: string, rowPatch: Partial<Row>)=> set({ rows: get().rows.map(r => (r.masterId === rowKey || r.sku === rowKey ? { ...r, ...rowPatch } : r)) }),
  loadOffers: async (scopedStoreId?: string) => {  // pick the scoped ID, else the one saved in global state
    const sid =
      scopedStoreId && scopedStoreId.trim().length > 0
        ? scopedStoreId
        : get().storeId;
    try {
      set({ loading: true, error: undefined })
      const url = `/api/pricebot/offers?withOpponents=false${sid ? `&storeId=${sid}` : ''}`;
      const res = await fetch(url, { cache:'no-store' })
      const js = await res.json()
      const items = Array.isArray(js?.items) ? js.items : []
      // Normalize to Row
      const rows = items.map((it: any) => ({          // <‑‑ add “: any”
        sku       : it.sku,
        name      : it.name,
        productId : it.productId,
        price     : it.price,
        stock     : it.stock,
      
        opponents : typeof it.opponents === 'number'
          ? it.opponents
          : Array.isArray(it.sellers) ? it.sellers.length : 0,
      
        // keep everything else that was already there
        settings  : it.settings ?? null,
      }))
      set({ rows })
    } catch (e:any) {
      set({ error: String(e?.message||e), rows: [] })
    } finally {
      set({ loading: false })
    }
  }
}), { name: 'pricebot:v1' }))


