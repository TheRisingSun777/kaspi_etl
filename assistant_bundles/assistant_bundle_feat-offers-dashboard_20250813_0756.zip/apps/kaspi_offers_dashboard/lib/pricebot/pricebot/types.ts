export type Row = {
  name: string;
  sku?: string;
  masterId: string;      // Kaspi master product id
  variantId?: string;
  ourPrice?: number;
  min?: number;
  max?: number;
  step?: number;
  intervalMin?: number;
  sellers?: { name: string; price: number; delivery?: string; isPriceBot?: boolean }[];
  sellersCount?: number;
  spread?: number;
  stock?: number;
  opponents?: number | null;
  deliveryBest?: string;
  ratingAvg?: number;
  ratingCount?: number;
  active?: boolean;
}


