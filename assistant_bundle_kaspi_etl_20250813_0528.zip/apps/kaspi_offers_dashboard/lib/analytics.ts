import type { AnalyzeResult, Variant } from './types'

export function basicStats(nums: number[]) {
  if (!nums.length) return { min: 0, median: 0, max: 0, spread: 0, stddev: 0 }
  const sorted = [...nums].sort((a,b)=>a-b)
  const min = sorted[0]
  const max = sorted[sorted.length-1]
  const spread = max - min
  const mid = Math.floor(sorted.length/2)
  const median = sorted.length % 2 ? sorted[mid] : (sorted[mid-1] + sorted[mid]) / 2
  const mean = sorted.reduce((a,b)=>a+b,0)/sorted.length
  const variance = sorted.reduce((a,b)=>a + (b-mean)*(b-mean), 0) / sorted.length
  const stddev = Math.sqrt(variance)
  return { min, median, max, spread, stddev }
}

export function computeVariantStats(v: Variant): Variant {
  const prices = (v.sellers || []).map(s => s.price).filter((n): n is number => Number.isFinite(n))
  const stats = basicStats(prices)
  return { ...v, sellersCount: v.sellers?.length || 0, stats: { ...v.stats, ...stats } }
}

export function computeGlobalAnalytics(result: AnalyzeResult): AnalyzeResult {
  const variants = result.variants.map(computeVariantStats)
  const spreads = variants.map(v => v.stats?.spread || 0).filter(n => n>0)
  const unique = new Set<string>()
  for (const v of variants) for (const s of v.sellers || []) unique.add(s.name.trim().toLowerCase())

  const avg = spreads.length ? spreads.reduce((a,b)=>a+b,0)/spreads.length : 0
  const median = (() => {
    if (!spreads.length) return 0
    const s = [...spreads].sort((a,b)=>a-b)
    const m = Math.floor(s.length/2)
    return s.length%2 ? s[m] : (s[m-1]+s[m])/2
  })()
  const max = spreads.length ? Math.max(...spreads) : 0

  // Heuristics
  let botCount = 0, sellerCount = 0
  for (const v of variants) {
    sellerCount += v.sellers?.length || 0
    for (const s of v.sellers || []) if (s.isPriceBot) botCount++
  }
  const botShare = sellerCount ? botCount / sellerCount : 0

  // Attractiveness: bigger spread, fewer sellers, more demand, faster delivery, less bot pressure
  // Scores are 0..1, then combined to 0..100
  const spreadScore = clamp01((avg / (median || avg || 1)))
  const scarcityScore = clamp01(1 - (unique.size / 20)) // 20 sellers = 0
  const demandScore = clamp01(Math.log10(((result.ratingCount || 0) + 1)) / 3) // ~0..1
  const botPenalty = clamp01(botShare) // higher = worse
  const attractivenessIndex = Math.round(
    100 * clamp01(0.45*spreadScore + 0.25*scarcityScore + 0.20*demandScore - 0.20*botPenalty)
  )

  // Stability: low relative stddev across variants is more stable
  const relStddevs = variants
    .map(v => (v.stats && v.stats.min ? (v.stats.stddev || 0) / (v.stats.min as number) : 0))
    .filter(x => Number.isFinite(x))
  const relStdAvg = relStddevs.length ? relStddevs.reduce((a,b)=>a+b,0)/relStddevs.length : 0
  const stabilityScore = Math.round(100 * clamp01(1 - relStdAvg)) // 1-relStdAvg

  // Best entry price: undercut min by a small step; dampen if bot pressure is high
  const minAcross = Math.min(...variants.map(v => v.stats?.min || Infinity))
  const step = priceStep(minAcross)
  const botDampen = botShare > 0.35 ? step * 0.25 : step
  const bestEntryPrice = Number.isFinite(minAcross) ? Math.max(0, Math.round((minAcross - botDampen)/10)*10) : 0

  // Fastest delivery aggregator: choose min lexicographically after normalizing dotted date parts
  const fastestDelivery = computeFastestDelivery(variants)

  return {
    ...result,
    variants,
    uniqueSellers: unique.size,
    fastestDelivery,
    analytics: { avgSpread: round0(avg), medianSpread: round0(median), maxSpread: round0(max), botShare: round2(botShare), attractivenessIndex, stabilityScore, bestEntryPrice },
  }
}

function priceStep(p:number){
  if (!Number.isFinite(p)) return 50
  if (p < 5000) return 20
  if (p < 20000) return 50
  if (p < 100000) return 100
  return 200
}
const clamp01 = (x:number)=> Math.max(0, Math.min(1, x))
const round0 = (n:number)=> Math.round(n||0)
const round2 = (n:number)=> Math.round((n||0)*100)/100

export function computeFastestDelivery(variants: Variant[]): string | undefined {
  const vals: string[] = []
  for (const v of variants) for (const s of v.sellers || []) if (s.deliveryDate) vals.push(normalizeDeliveryOrderKey(s.deliveryDate))
  if (!vals.length) return undefined
  vals.sort()
  const best = vals[0]
  return denormalizeDeliveryOrderKey(best)
}

function normalizeDeliveryOrderKey(s: string): string {
  // Extract DD.MM.YYYY or DD.MM.YY and left pad to sortable key; fallback to raw string
  const m = s.match(/(\d{1,2})\.(\d{1,2})\.(\d{2,4})/)
  if (!m) return 'ZZZ|' + s
  const d = m[1].padStart(2, '0')
  const mo = m[2].padStart(2, '0')
  let y = m[3]
  if (y.length === 2) y = '20' + y
  return `${y}-${mo}-${d}|${s}`
}
function denormalizeDeliveryOrderKey(k: string): string {
  const idx = k.indexOf('|')
  return idx >= 0 ? k.slice(idx+1) : k
}


