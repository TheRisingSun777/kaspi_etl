export type RunInput = { currentPrice: number; minPrice?: number; maxPrice?: number; stepKzt?: number; opponents: Array<{ merchantId: string; price: number }>; ignore: string[] }
export type RunResult = { newPrice: number; reason: string }

export function computeProposal(input: RunInput): RunResult {
  const step = Math.max(1, Math.round(input.stepKzt || 1))
  const min = typeof input.minPrice==='number' ? input.minPrice : 0
  const max = typeof input.maxPrice==='number' ? input.maxPrice : Number.POSITIVE_INFINITY
  const opp = input.opponents.filter(o=>!input.ignore.includes(String(o.merchantId)))
  opp.sort((a,b)=>a.price-b.price)
  const best = opp[0]?.price
  let target = input.currentPrice
  let reason = 'no-change'
  if (typeof best==='number' && best < input.currentPrice) {
    target = best - step
    reason = `beat best ${best} by step ${step}`
  }
  target = Math.min(Math.max(target, min), max)
  return { newPrice: Math.max(0, Math.round(target)), reason }
}


