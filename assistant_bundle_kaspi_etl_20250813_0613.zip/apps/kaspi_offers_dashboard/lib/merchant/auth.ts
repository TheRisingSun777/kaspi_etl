// lib/merchant/auth.ts
export function buildAuthHeaders(): Record<string, string> {
  const apiKey = process.env.KASPI_MERCHANT_API_KEY || ''
  const cookies = process.env.KASPI_MERCHANT_COOKIES || ''
  const headers: Record<string,string> = {
    Accept: 'application/json',
    'User-Agent': 'KaspiOffersDashboard/1.0',
  }
  if (apiKey) {
    headers['x-auth-version'] = '3'
    headers['Authorization'] = `Bearer ${apiKey}`
  } else if (cookies) {
    headers['Cookie'] = cookies
  }
  return headers
}


