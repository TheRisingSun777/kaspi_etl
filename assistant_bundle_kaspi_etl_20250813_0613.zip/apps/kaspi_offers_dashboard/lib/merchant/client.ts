import { buildAuthHeaders } from './auth'

const BASE = process.env.KASPI_MERCHANT_API_BASE || 'https://mc.shop.kaspi.kz'
const MID  = process.env.KASPI_MERCHANT_ID || '30141222'

async function fetchJSON(path: string, init: RequestInit = {}) {
  const res = await fetch(`${BASE}${path}`, {
    cache: 'no-store',
    ...init,
    headers: { ...buildAuthHeaders(), ...(init.headers as any) },
  })
  const text = await res.text()
  if (!res.ok) throw new Error(`HTTP ${res.status} ${res.statusText} :: ${text.slice(0,200)}`)
  try { return JSON.parse(text) } catch { return text }
}

export async function getOffersPage(page = 0, limit = 100) {
  const q = new URLSearchParams({ m: MID, p: String(page), l: String(limit), a: 'true', lowStock: 'false', notSpecifiedStock: 'false' })
  return fetchJSON(`/bff/offer-view/list?${q.toString()}`)
}

export async function getOfferDetailsBySku(sku: string) {
  const q = new URLSearchParams({ m: MID, s: sku })
  return fetchJSON(`/bff/offer-view/details?${q.toString()}`)
}

export async function postDiscount(body: { merchantUID: string; merchantSKU: string; entries: { city: string; price: number }[] }) {
  return fetchJSON(`/price/trends/api/v1/mc/discount`, {
    method: 'POST',
    headers: { 'Content-Type':'application/json' },
    body: JSON.stringify(body),
  })
}


