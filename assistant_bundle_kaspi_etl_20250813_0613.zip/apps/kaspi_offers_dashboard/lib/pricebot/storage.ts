import fs from 'node:fs'
import path from 'node:path'

export type BotSettings = {
  min: number
  max: number
  step: number
  interval: number
  active: boolean
  ignoreSellers: string[]
}

type Store = Record<string, BotSettings>

const FILE = path.join(process.cwd(), 'apps', 'kaspi_offers_dashboard', 'server', 'db', 'pricebot.json')

function ensureDir(): void {
  const dir = path.dirname(FILE)
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
}

export function readStore(): Store {
  try {
    const raw = fs.readFileSync(FILE, 'utf-8')
    return JSON.parse(raw) as Store
  } catch {
    return {}
  }
}

export function writeStore(st: Store): void {
  ensureDir()
  fs.writeFileSync(FILE, JSON.stringify(st, null, 2))
}

export function getSettings(sku: string): BotSettings {
  const st = readStore()
  return st[sku] || { min: 0, max: 0, step: 1, interval: 5, active: false, ignoreSellers: [] }
}

export function upsertSettings(sku: string, patch: Partial<BotSettings>): BotSettings {
  const st = readStore()
  const cur = st[sku] || { min: 0, max: 0, step: 1, interval: 5, active: false, ignoreSellers: [] }
  st[sku] = { ...cur, ...patch }
  writeStore(st)
  return st[sku]
}

export function toggleIgnore(sku: string, seller: string, ignore: boolean): BotSettings {
  const st = readStore()
  const cur = st[sku] || { min: 0, max: 0, step: 1, interval: 5, active: false, ignoreSellers: [] }
  const set = new Set(cur.ignoreSellers)
  if (ignore) set.add(seller)
  else set.delete(seller)
  st[sku] = { ...cur, ignoreSellers: Array.from(set) }
  writeStore(st)
  return st[sku]
}


